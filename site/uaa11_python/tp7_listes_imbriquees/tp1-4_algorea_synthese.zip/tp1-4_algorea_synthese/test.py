from robot import *

def test1():
    set_dt(100)
    select_jeu(1)

    # nb lignes: 11
    for loop in range(3):
        for loop in range(6):
            est()
        for loop in range(3):
            sud()
        for loop in range(3):
            ouest()
        for loop in range(3):
            nord()
        for loop in range(3):
            est()        

def test2():
    set_dt(100)

    select_jeu(2)

    # nb lignes: 9
    def carre():
        for loop in range(6):
            est()
        for loop in range(3):
            sud()
        for loop in range(3):
            ouest()
        for loop in range(3):
            nord()
        for loop in range(3):
            est()
    
    carre()
    est()
    carre()
    est()
    est()
    carre()   
   

def test3():
    select_jeu(3)
    set_dt(100)

    # nb lignes: 7
    pass



test3()

base.mainloop()
